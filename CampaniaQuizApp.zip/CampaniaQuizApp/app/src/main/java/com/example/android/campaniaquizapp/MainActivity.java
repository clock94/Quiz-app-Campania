package com.example.android.campaniaquizapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startQuiz(View view) {
        EditText nameEditText = (EditText) findViewById(R.id.intro_edit_text);
        String editText = nameEditText.getText().toString();
        Intent intent = new Intent(this, question1.class);

        if (TextUtils.isEmpty(editText)) {
            Toast toast = Toast.makeText(this, getString(R.string.toast), LENGTH_SHORT);
            toast.show();
        } else {

            startActivity(intent);
        }
    }
}


