package com.example.android.campaniaquizapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

/**
 * Created by Clock on 17/06/2017.
 */

public class question1 extends AppCompatActivity {

     int totalPoint =0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question1);
    }

    public int scoreQuestion1(View view) {
        totalPoint = totalPoint + 1;
        return totalPoint;
    }


    static final String myExtraToBePassed= "scoreToBePassed";

    public void nextQuestion2(View view) {
        Intent intent = new Intent(this, question2.class);
        intent.putExtra("myExtraToBePassed",totalPoint);
        CheckBox BeneventoCheckBox = (CheckBox) findViewById(R.id.benevento_check_box);
        Boolean Benevento = BeneventoCheckBox.isChecked();


        CheckBox NapoliCheckBox = (CheckBox) findViewById(R.id.napoli_check_box);
        Boolean Napoli = NapoliCheckBox.isChecked();


        CheckBox AvellinoCheckBox = (CheckBox) findViewById(R.id.avellino_check_box);
        Boolean Avellino = AvellinoCheckBox.isChecked();

        CheckBox SalernoCheckBox = (CheckBox) findViewById(R.id.salerno_check_box);
        Boolean Salerno = SalernoCheckBox.isChecked();

        CheckBox CasertaCheckBox = (CheckBox) findViewById(R.id.caserta_check_box);
        Boolean Caserta = CasertaCheckBox.isChecked();

        if (Napoli) {
            Toast.makeText(this, "You get " +totalPoint , Toast.LENGTH_SHORT).show();
        }
        if (Salerno) {
            Toast.makeText(this, "You get " + totalPoint, Toast.LENGTH_SHORT).show();
        }
        if(Napoli&&Salerno){
            Toast.makeText(this, "You get 1 point bonus " +totalPoint, Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }

         if (Benevento) {
            Toast.makeText(this, "Wrong Answer!" + 0, Toast.LENGTH_SHORT).show();
            startActivity(intent);
        } else if (Avellino) {
            Toast.makeText(this, "Wrong Answer!" + 0, Toast.LENGTH_SHORT).show();
            startActivity(intent);
        } else if (Caserta) {
            Toast.makeText(this, "Wrong Answer!" + 0, Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
}