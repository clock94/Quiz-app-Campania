package com.example.android.campaniaquizapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Clock on 28/06/2017.
 */

public class question3 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question3);
    }
}
