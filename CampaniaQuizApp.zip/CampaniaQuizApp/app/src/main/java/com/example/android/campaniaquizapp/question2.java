package com.example.android.campaniaquizapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

/**
 * Created by Clock on 19/06/2017.
 */

public class question2 extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question2);
    }

    public void onRadioButtonOnClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.romani_radio_button:
                if (checked)
                    Toast.makeText(this, "Wrong Answer!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.greci_radio_button:
                if (checked)
                    Toast.makeText(this, "Wrong Answer!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.bizantini_radio_button:
                if (checked)
                    Toast.makeText(this, "Wrong Answer!", Toast.LENGTH_SHORT).show();
                break;

        }
    }
    public void nextQuestion3 (View view){
        Intent intent = new Intent(this, question3.class);
        Bundle totalPoint=getIntent().getExtras();
        String point = totalPoint.getString("myExtraToBePassed");
        RadioButton radioButtonCumani= (RadioButton) findViewById(R.id.cumani_radio_button);
       boolean cumani= radioButtonCumani.isChecked();
        if(cumani){
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "You get  "+ totalPoint, Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
}
